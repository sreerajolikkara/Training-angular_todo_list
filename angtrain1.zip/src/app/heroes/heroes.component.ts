import { Component, OnInit } from '@angular/core';
import { ThrowStmt } from '@angular/compiler';


@Component({
  selector: 'app-heroes',
  templateUrl: './heroes.component.html',
  styleUrls: ['./heroes.component.css']
})
export class HeroesComponent implements OnInit {
  herp=[{id:1,name:'apple'},{id:2,name:'orange'},{id:3,name:'banana'}];
  selectedhero=null;
  x=null;
  y=null;
  edit=null;
  newid=null;
  newname=null
  selectedrow=-1;
  su=0;
  c=0;

  onselect(hero)
  {
    this.selectedhero=hero;
  }
  sum1()
  { this.su=0;
    for(let i in this.herp)
    this.su=this.su+this.herp[i].id;
  console.log(this.su)
  this.c=1;
  }
  add()
  {
    this.herp.push({id:this.x,name:this.y});
  }
  delete(n)
  {
    this.herp.splice(n,1);
  }
  editon(n)
  {
    this.edit=1;
    this.selectedrow=n;
  }

  sureedit(n)
  {
    
    if(n===this.selectedrow)
    {this.herp[n].id=this.newid;
      this.herp[n].name=this.newname;
    this.edit=null;}
      

  }
  constructor() { 
  
  }

  ngOnInit() {
  }

}
