export default interface Todo {
    userId: number
    id: number
    title: string
    comlpeted: boolean
}